//
//  DVTTextCompletionListWindowController+KSImageNamed.h
//  KSImageNamed
//
//  Created by Jack Chen on 24/10/2013.
//
//

#import "XcodeMisc.h"

@interface DVTTextCompletionListWindowController (KSImageNamed)

@end
