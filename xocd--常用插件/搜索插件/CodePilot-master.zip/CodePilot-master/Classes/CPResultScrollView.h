//
//  CPResultScrollView.h
//  CodePilot
//
//  Created by Zbigniew Sobiecki on 5/26/11.
//  Copyright 2011 Macoscope. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface CPResultScrollView : NSScrollView
@end
