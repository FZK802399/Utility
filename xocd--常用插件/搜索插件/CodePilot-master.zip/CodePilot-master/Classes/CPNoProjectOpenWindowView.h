//
//  NoProjectOpenWindowView.h
//  CodePilot
//
//  Created by Zbigniew Sobiecki on 3/19/10.
//  Copyright 2010 Macoscope. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "CPInfoWindowView.h"

@interface CPNoProjectOpenWindowView : CPInfoWindowView
@end
