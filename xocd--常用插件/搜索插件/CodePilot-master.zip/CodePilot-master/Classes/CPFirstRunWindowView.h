//
//  CPFirstRunWindowView.h
//  CodePilot
//
//  Created by Zbigniew Sobiecki on 3/21/10.
//  Copyright 2010 Macoscope. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "CPInfoWindowView.h"

@interface CPFirstRunWindowView : CPInfoWindowView
@end
