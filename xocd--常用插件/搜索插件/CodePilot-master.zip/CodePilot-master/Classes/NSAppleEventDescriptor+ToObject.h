//
//  NSAppleEventDescriptor+ToObject.h
//  Quark
//
//  Created by Daniel on 09-10-15.
//  Copyright 2009 Macosope. All rights reserved.
//

#import <Cocoa/Cocoa.h>

//http://github.com/Grayson/applescripttodictionarywithnutoo
@interface NSAppleEventDescriptor (ToObject)
- (id)toObject;

@end
